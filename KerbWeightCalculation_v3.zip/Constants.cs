﻿namespace KerbWeightCalculation
{
    public static class Constants
    {
        public const string WAVE_PDM_ENV_PATH = "";
    }
}