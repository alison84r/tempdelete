﻿using System.Collections.Generic;
using NXOpen.Assemblies;

namespace KerbWeightCalculation
{
    public class ComponentDisplayNameComparer : IEqualityComparer<Component>
    {
        public bool Equals(Component x, Component y)
        {
            if (x == null && y == null)
                return true;
            else if (x == null || y == null)
                return false;

            return x.DisplayName == y.DisplayName;
        }

        public int GetHashCode(Component obj)
        {
            return obj.DisplayName.GetHashCode();
        }
    }

}