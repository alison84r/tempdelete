﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using Microsoft.Office.Interop.Excel;
using NXOpen;
using NXOpen.Assemblies;
using NXOpen.Features.AECDesign;
using NXOpen.Markup;
using NXOpen.UF;
using static NXOpen.LoadOptions;
using Excel = Microsoft.Office.Interop.Excel;

namespace KerbWeightCalculation
{
    public class WeightMain
    {
        private static Session theSession = Session.GetSession();
        private static UI theUI = UI.GetUI();
        private static UFSession theUfSession = UFSession.GetUFSession();
        private static int numParts = 0;
        private static Part workPart = theSession.Parts.Work;

        public static void Main(string[] args)
        {
            // Start timer
            DateTime startTime = DateTime.Now;

           // ListingWindow lw = theSession.ListingWindow;
            Part workPart = theSession.Parts.Work;

            //lw.Open();
            //lw.WriteLine(workPart.FullPath);
            numParts += 1;
            int level = 0;

            List<Component> zeroMassComponents = new List<Component>();
            Component rootComp = workPart.ComponentAssembly.RootComponent;
            if (rootComp != null)
            {
                List<ComponentData> rootComponentDatas = new List<ComponentData>(0);
                List<Component> firstLevelChildComponents = GetFirstLevelChildComponents(rootComp, "MOD");
                foreach (Component child in firstLevelChildComponents)
                {
                    ComponentData childComponentData = new ComponentData();
                    childComponentData.Component = child;
                    childComponentData.Level = 1;
                    childComponentData.CompName = child.DisplayName.ToUpper();
                    childComponentData.CgX = 0;
                    childComponentData.CgY = 0;
                    childComponentData.CgZ = 0;
                    childComponentData.Mass = 0;
                    childComponentData.Parent = null;
                    childComponentData.Child = new List<ComponentData>(0);
                    List<Component> childComponentsBySubstring = GetChildComponentsBySubstring(child, "Z400");
                    foreach (Component component in childComponentsBySubstring)
                    {
                        ComponentData componentData = new ComponentData();
                        componentData.Component = component;
                        componentData.Level = 3;
                        componentData.CompName = component.DisplayName.ToUpper();
                        componentData.CgX = 0;
                        componentData.CgY = 0;
                        componentData.CgZ = 0;
                        componentData.Mass = 0;
                        componentData.Parent = childComponentData;

                        double totalMass = 0.0;
                        double totalCgX = 0.0;
                        double totalCgY = 0.0;
                        double totalCgZ = 0.0;

                        List<Component> allComponentsWithPartTypePrt = GetAllComponentsWithPartType(component);
                        foreach (Component component1 in allComponentsWithPartTypePrt)
                        {
                            //Calculate the weight;
                            double mass = GetDoubleAttributeValue(component1, "");

                            // Update the total mass
                            totalMass += mass;

                            if (mass == 0.0)
                            {
                                zeroMassComponents.Add(component1);
                                
                            }


                            double cgX = GetDoubleAttributeValue(component1, "");
                            double cgY = GetDoubleAttributeValue(component1, "");
                            double cgZ = GetDoubleAttributeValue(component1, "");

                            // Update the sum of weighted positions
                            totalCgX += mass * cgX;
                            totalCgY += mass * cgY;
                            totalCgZ += mass * cgZ;
                        }

                        componentData.CgX = totalCgX;
                        componentData.CgY = totalCgY;
                        componentData.CgZ = totalCgZ;
                        componentData.Mass = totalMass;
                        childComponentData.Child.Add(componentData);
                    }
                    rootComponentDatas.Add(childComponentData);

                }
                // Remove duplicates based on DisplayName
                zeroMassComponents = zeroMassComponents.Distinct(new ComponentDisplayNameComparer()).ToList();
                WriteToExcel(rootComponentDatas, zeroMassComponents);

                //List<ComponentData> componentDatas = ReadLevel1Components(rootComp);
                //compsWithZeroMass = new List<ComponentData>(0);
                //ReportComponentsWithZeroMass(rootComp,ref compsWithZeroMass);
               // if (componentDatas.Any())
                //{
                    //WriteToExcel(componentDatas, compsWithZeroMass);
                //}
            }

            // End timer
            DateTime endTime = DateTime.Now;

            // Calculate elapsed time in minutes
            TimeSpan timeElapsed = endTime - startTime;
            double minutesElapsed = Math.Round(timeElapsed.TotalMinutes,2);

            // Print elapsed time
            theUI.NXMessageBox.Show("Kerb Weight", NXMessageBox.DialogType.Information,
                "KERB Weight Calculation completed in " + minutesElapsed + " minutes");
            Console.WriteLine("Elapsed time: " + minutesElapsed + " minutes");
        }

        public static List<Component> GetFirstLevelChildComponents(Component rootComponent, string nameContains)
        {
            List<Component> firstLevelChildComponents = new List<Component>();

            foreach (Component child in rootComponent.GetChildren())
            {
                if (child.IsSuppressed || child.IsBlanked)
                {
                    continue;
                }
                string partType = GetPartTypeAttribute(child);
                if (partType.Equals("ASM") && child.Name.Contains(nameContains))
                    firstLevelChildComponents.Add(child);
            }

            return firstLevelChildComponents;
        }

        private static string GetPartTypeAttribute(Component component)
        {
            string partType = string.Empty;
            string attributeValue = GetStringAttributeValue(component, "RNI_PARTTYPE");
            if (!string.IsNullOrEmpty(attributeValue))
            {
                partType = attributeValue;
            }
            return partType;
        }

        public static List<Component> GetChildComponentsBySubstring(Component rootComponent, string z400)
        {
            List<Component> childComponents = new List<Component>();
            TraverseComponent(rootComponent, childComponents, z400);
            return childComponents;
        }

        private static void TraverseComponent(Component component, List<Component> matchingComponents, string nameSubstring)
        {
            string partType = GetPartTypeAttribute(component);

            if (component.Name.ToUpper().Contains(nameSubstring.ToUpper()))
            {
                matchingComponents.Add(component);
            }

            if (partType.Equals("ASM"))
            {
                foreach (Component child in component.GetChildren())
                {
                    if (child.IsSuppressed || child.IsBlanked)
                    {
                        continue;
                    }
                    TraverseComponent(child, matchingComponents, nameSubstring);
                }
            }
        }

        private static List<Component> GetAllComponentsWithPartType(Component component)
        {
            List<Component> componentsWithPartType = new List<Component>();

            TraverseComponent(component, componentsWithPartType);

            return componentsWithPartType;
        }

        private static void TraverseComponent(Component component, List<Component> componentsWithPartType)
        {
            string partType = GetPartTypeAttribute(component);

            if (partType.Equals("PRT"))
            {
                componentsWithPartType.Add(component);
            }

            if (partType.Equals("ASM"))
            {
                foreach (Component child in component.GetChildren())
                {
                    if (child.IsSuppressed || child.IsBlanked)
                    {
                        continue;
                    }
                    TraverseComponent(child, componentsWithPartType);
                }
            }
        }

        public static double GetDoubleAttributeValue(NXObject iNxObject, string iAttributeName)
        {
            string attributeValue = GetStringAttributeValue(iNxObject, iAttributeName);

            double result;
            if (string.IsNullOrEmpty(attributeValue) || !double.TryParse(attributeValue, out result))
            {
                result = 0.0;
            }

            return result;
        }
        public static string GetStringAttributeValue(NXObject iNxObject, string iAttributeName)
        {
            string attributeValue = "";
            if(!string.IsNullOrEmpty(iAttributeName))
            {
                if (iNxObject.HasUserAttribute(iAttributeName, NXObject.AttributeType.String, -1))
                {
                    attributeValue = iNxObject.GetStringUserAttribute(iAttributeName, -1);
                }
            }
            return attributeValue;
        }

        public static List<ComponentData> ReadLevel1Components(Component parent)
        {
            Component[] children = parent.GetChildren();
            List<ComponentData> rootComponentDatas = new List<ComponentData>(0);
            foreach (Component level1child in children)
            {
                if (level1child.IsSuppressed || level1child.IsBlanked)
                {
                    continue;
                }
                ComponentData level1CompData = FillMassAndCgOfComponent(level1child, null, 1);
                level1CompData.Child = new List<ComponentData>(0);
                rootComponentDatas.Add(level1CompData);
                //read level 2 Child
                Component[] level2Comps = level1child.GetChildren();
                if (level2Comps.Any())
                {
                    foreach (Component level2child in level2Comps)
                    {
                        if (level2child.GetChildren().Any())
                        {
                            //Collect all the components if level 3
                            foreach (Component level3Child in level2child.GetChildren())
                            {
                                if (level3Child.IsSuppressed || level3Child.IsBlanked)
                                {
                                    continue;
                                }
                                ComponentData level3CompData = FillMassAndCgOfComponent(level3Child, level1CompData, 3);
                                level1CompData.Child.Add(level3CompData);
                            }
                        }
                    }
                }
            }

            return rootComponentDatas;
        }

        public static void WriteToExcel(List<ComponentData> level1CompsData, List<Component> zeroMassComponents)
        {
            // Create a new Excel workbook
            Excel.Application excel = new Excel.Application();
            Excel.Workbook workbook = excel.Workbooks.Add();

            int row = 2;

            //Add the Sheet for zero Mass Components
            Worksheet zeroMassSheet = (Worksheet)workbook.Sheets.Add();
            zeroMassSheet.Name = "Zero Mass";
            zeroMassSheet.Cells[1, 1].Value = "Name";
            zeroMassSheet.Cells[1, 2].Value = "Mass in Kgs";
            foreach (Component compWithZeroMass in zeroMassComponents)
            {
                zeroMassSheet.Cells[row, 1].Value = compWithZeroMass.DisplayName.ToUpper();
                zeroMassSheet.Cells[row, 2].Value = 0;

                row++;
            }

            row = 2;
            // Add the summary sheet
            Worksheet summarySheet = (Worksheet)workbook.Sheets.Add();
            summarySheet.Name = "Summary";
            summarySheet.Cells[1, 1].Value = "Name";
            summarySheet.Cells[1, 2].Value = "Mass in Kgs";
            summarySheet.Cells[1, 3].Value = "CgX";
            summarySheet.Cells[1, 4].Value = "CgY";
            summarySheet.Cells[1, 5].Value = "CgZ";

           

            // Loop through the top-level components and add them to the summary sheet
            foreach (ComponentData componentData in level1CompsData)
            {

                summarySheet.Cells[row, 1].Value = componentData.CompName;
                summarySheet.Cells[row, 2].Value = componentData.Mass;
                summarySheet.Cells[row, 3].Value = componentData.CgX;
                summarySheet.Cells[row, 4].Value = componentData.CgY;
                summarySheet.Cells[row, 5].Value = componentData.CgZ;

                row++;

               

                // Add a new sheet for the component
                Worksheet componentSheet = (Worksheet)workbook.Sheets.Add();
                componentSheet.Name = componentData.CompName;
                componentSheet.Cells[1, 1].Value = "Name";
                componentSheet.Cells[1, 2].Value = "Mass in Kgs";
                componentSheet.Cells[1, 3].Value = "CgX";
                componentSheet.Cells[1, 4].Value = "CgY";
                componentSheet.Cells[1, 5].Value = "CgZ";

                // Loop through the child components and add them to the component sheet
                int childRow = 2;
                foreach (ComponentData childComponentData in componentData.Child)
                {
                    componentSheet.Cells[childRow, 1].Value = childComponentData.CompName;
                    componentSheet.Cells[childRow, 2].Value = childComponentData.Mass;
                    componentSheet.Cells[childRow, 3].Value = childComponentData.CgX;
                    componentSheet.Cells[childRow, 4].Value = childComponentData.CgY;
                    componentSheet.Cells[childRow, 5].Value = childComponentData.CgZ;
                    if (childComponentData.Mass == 0)
                    {
                        componentSheet.Cells[childRow,2].Interior.Color = Excel.XlRgbColor.rgbRed;
                    }
                    childRow++;
                }
            }

            // loop through all sheets
            foreach (Worksheet ws in workbook.Worksheets)
            {
                // set current sheet as active sheet
                Worksheet worksheet = ws;
                worksheet.Activate();

                // set first row as header and make it bold
                Range headerRange = worksheet.Range["A1", "E1"];
                headerRange.Font.Bold = true;

                // set fill color for header
                headerRange.Interior.Color = ColorTranslator.ToOle(Color.LightGray);

                // auto-adjust columns
                worksheet.Columns.AutoFit();

                // highlight cells with mass value zero
                //foreach (Range cell in worksheet.UsedRange.Cells)
                //{
                //    if (cell.Value != null && cell.Value.ToString() == "0")
                //    {
                //        cell.Interior.Color = ColorTranslator.ToOle(Color.Red);
                //    }
                //}
            }


            // Move Zero Mass sheet to beginning
            zeroMassSheet.Move(workbook.Sheets[1]);

            // Move summary sheet to beginning
            summarySheet.Move(workbook.Sheets[2]);

            // Save and close the workbook
            workbook.SaveAs(@"C:\Users\HP\Downloads\DICV\AssemblyData.xlsx");
            workbook.Close();
            excel.Quit();
        }

        public static ComponentData FillMassAndCgOfComponent(Component iComp, ComponentData iParent,int level)
        {
            UFWeight.UnitsType use_units;
            if (workPart.PartUnits == BasePart.Units.Millimeters)
            {
                use_units = UFWeight.UnitsType.UnitsKmm;
            }
            else
            {
                use_units = UFWeight.UnitsType.UnitsLi;
            }
            UFWeight.Properties props = new UFWeight.Properties();
            UFWeight.Exceptions[] exceptions = { new UFWeight.Exceptions() };
            theUfSession.Weight.EstabCompProps1(iComp.Tag, 0.99, true, use_units, out props, out exceptions);
            double propsMass = Math.Round(props.mass, 2);

            ComponentData componentData = new ComponentData();
            componentData.Component = iComp;
            componentData.Level = level;
            componentData.CompName = iComp.DisplayName;
            componentData.CgX = Math.Round(props.center_of_mass[0],2);
            componentData.CgY = Math.Round(props.center_of_mass[1], 2);
            componentData.CgZ = Math.Round(props.center_of_mass[2], 2);
            componentData.Mass = propsMass;
            componentData.Parent = iParent;

            
            /*
            Echo(String.Format("{0,-8}{1,-40}{2,-20}{3,-20}{4,-20}{5,-20}",
                level,
                iComp.DisplayName,
                propsMass + " Kg",
                Math.Round(props.center_of_mass[0], 2),
                Math.Round(props.center_of_mass[1], 2),
                Math.Round(props.center_of_mass[2], 2)));

            */


            return componentData;
        }
        public static void ReportComponentsWithZeroMass(Component parent,ref List<ComponentData> compsWithZeroMass)
        {
            Component[] children = parent.GetChildren();

            foreach (Component child in children)
            {
                if (child.IsSuppressed || child.IsBlanked)
                {
                    continue;
                }
                try
                {
                    UFWeight.UnitsType use_units;
                    if (workPart.PartUnits == BasePart.Units.Millimeters)
                    {
                        use_units = UFWeight.UnitsType.UnitsKmm;
                    }
                    else
                    {
                        use_units = UFWeight.UnitsType.UnitsLi;
                    }

                    UFWeight.Properties props = new UFWeight.Properties();
                    UFWeight.Exceptions[] exceptions = { new UFWeight.Exceptions() };

                    theUfSession.Weight.EstabCompProps1(child.Tag, 0.99, true, use_units, out props, out exceptions);
                    double propsMass = Math.Round(props.mass, 2);
                    if (propsMass <= 0)
                    {
                        ComponentData componentData = new ComponentData();
                        componentData.CompName = child.DisplayName;
                        componentData.Mass = propsMass;
                        compsWithZeroMass.Add(componentData);
                    }
                    ReportComponentsWithZeroMass(child,ref compsWithZeroMass);
                }
                catch
                {
                }
            }
        }
        private static void Echo(string message)
        {
            Session.GetSession().ListingWindow.WriteLine(message);
        }
        public static int GetUnloadOption(string dummy) { return (int)NXOpen.Session.LibraryUnloadOption.Immediately; }
    }
}