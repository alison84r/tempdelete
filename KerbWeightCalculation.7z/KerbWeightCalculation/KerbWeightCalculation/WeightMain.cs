﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using Microsoft.Office.Interop.Excel;
using NXOpen;
using NXOpen.Assemblies;
using NXOpen.Features.AECDesign;
using NXOpen.Markup;
using NXOpen.UF;
using static NXOpen.LoadOptions;
using Excel = Microsoft.Office.Interop.Excel;

namespace KerbWeightCalculation
{
    public class WeightMain
    {
        private static Session theSession = Session.GetSession();
        private static UI theUI = UI.GetUI();
        private static UFSession theUfSession = UFSession.GetUFSession();
        private static int numParts = 0;
        private static Part workPart = theSession.Parts.Work;

        public static void Main(string[] args)
        {
            // Start timer
            DateTime startTime = DateTime.Now;

            ListingWindow lw = theSession.ListingWindow;
            Part workPart = theSession.Parts.Work;

            lw.Open();
            lw.WriteLine(workPart.FullPath);
            numParts += 1;
            int level = 0;

            Component rootComp = workPart.ComponentAssembly.RootComponent;
            if (rootComp != null)
            {
                List<ComponentData> componentDatas = ReadLevel1Components(rootComp);
                List<ComponentData> compsWithZeroMass = new List<ComponentData>(0);
                ReportComponentsWithZeroMass(rootComp,ref compsWithZeroMass);
                if (componentDatas.Any())
                {
                    WriteToExcel(componentDatas, compsWithZeroMass);
                }
            }

            // End timer
            DateTime endTime = DateTime.Now;

            // Calculate elapsed time in minutes
            TimeSpan timeElapsed = endTime - startTime;
            double minutesElapsed = Math.Round(timeElapsed.TotalMinutes,2);

            // Print elapsed time
            theUI.NXMessageBox.Show("Kerb Weight", NXMessageBox.DialogType.Information,
                "KERB Weight Calculation completed in " + minutesElapsed + " minutes");
            Console.WriteLine("Elapsed time: " + minutesElapsed + " minutes");
        }

        public static List<ComponentData> ReadLevel1Components(Component parent)
        {
            Component[] children = parent.GetChildren();
            List<ComponentData> level1CompsData = new List<ComponentData>(0);
            foreach (Component level1child in children)
            {
                if (level1child.IsSuppressed || level1child.IsBlanked)
                {
                    continue;
                }
                ComponentData level1CompData = FillMassAndCgOfComponent(level1child, null, 1);
                level1CompData.Child = new List<ComponentData>(0);
                level1CompsData.Add(level1CompData);
                //read level 2 Child
                Component[] level2Comps = level1child.GetChildren();
                if (level2Comps.Any())
                {
                    foreach (Component level2child in level2Comps)
                    {
                        if (level2child.GetChildren().Any())
                        {
                            //Collect all the components if level 3
                            foreach (Component level3Child in level2child.GetChildren())
                            {
                                if (level3Child.IsSuppressed || level3Child.IsBlanked)
                                {
                                    continue;
                                }
                                ComponentData level3CompData = FillMassAndCgOfComponent(level3Child, level1CompData, 3);
                                level1CompData.Child.Add(level3CompData);
                            }
                        }
                    }
                }
            }

            return level1CompsData;
        }

        public static void WriteToExcel(List<ComponentData> level1CompsData, List<ComponentData> iCompsWithZeroMass)
        {
            // Create a new Excel workbook
            Excel.Application excel = new Excel.Application();
            Excel.Workbook workbook = excel.Workbooks.Add();

            int row = 2;

            //Add the Sheet for zero Mass Components
            Worksheet zeroMassSheet = (Worksheet)workbook.Sheets.Add();
            zeroMassSheet.Name = "Zero Mass";
            zeroMassSheet.Cells[1, 1].Value = "Name";
            zeroMassSheet.Cells[1, 2].Value = "Mass in Kgs";
            foreach (ComponentData compWithZeroMass in iCompsWithZeroMass)
            {
                zeroMassSheet.Cells[row, 1].Value = compWithZeroMass.CompName;
                zeroMassSheet.Cells[row, 2].Value = compWithZeroMass.Mass;

                row++;
            }

            row = 2;
            // Add the summary sheet
            Worksheet summarySheet = (Worksheet)workbook.Sheets.Add();
            summarySheet.Name = "Summary";
            summarySheet.Cells[1, 1].Value = "Name";
            summarySheet.Cells[1, 2].Value = "Mass in Kgs";
            summarySheet.Cells[1, 3].Value = "CgX";
            summarySheet.Cells[1, 4].Value = "CgY";
            summarySheet.Cells[1, 5].Value = "CgZ";

           

            // Loop through the top-level components and add them to the summary sheet
            foreach (ComponentData componentData in level1CompsData)
            {

                summarySheet.Cells[row, 1].Value = componentData.CompName;
                summarySheet.Cells[row, 2].Value = componentData.Mass;
                summarySheet.Cells[row, 3].Value = componentData.CgX;
                summarySheet.Cells[row, 4].Value = componentData.CgY;
                summarySheet.Cells[row, 5].Value = componentData.CgZ;

                row++;

               

                // Add a new sheet for the component
                Worksheet componentSheet = (Worksheet)workbook.Sheets.Add();
                componentSheet.Name = componentData.CompName;
                componentSheet.Cells[1, 1].Value = "Name";
                componentSheet.Cells[1, 2].Value = "Mass in Kgs";
                componentSheet.Cells[1, 3].Value = "CgX";
                componentSheet.Cells[1, 4].Value = "CgY";
                componentSheet.Cells[1, 5].Value = "CgZ";

                // Loop through the child components and add them to the component sheet
                int childRow = 2;
                foreach (ComponentData childComponentData in componentData.Child)
                {
                    componentSheet.Cells[childRow, 1].Value = childComponentData.CompName;
                    componentSheet.Cells[childRow, 2].Value = childComponentData.Mass;
                    componentSheet.Cells[childRow, 3].Value = childComponentData.CgX;
                    componentSheet.Cells[childRow, 4].Value = childComponentData.CgY;
                    componentSheet.Cells[childRow, 5].Value = childComponentData.CgZ;
                    if (childComponentData.Mass == 0)
                    {
                        componentSheet.Cells[childRow,2].Interior.Color = Excel.XlRgbColor.rgbRed;
                    }
                    childRow++;
                }
            }

            // loop through all sheets
            foreach (Worksheet ws in workbook.Worksheets)
            {
                // set current sheet as active sheet
                Worksheet worksheet = ws;
                worksheet.Activate();

                // set first row as header and make it bold
                Range headerRange = worksheet.Range["A1", "E1"];
                headerRange.Font.Bold = true;

                // set fill color for header
                headerRange.Interior.Color = ColorTranslator.ToOle(Color.LightGray);

                // auto-adjust columns
                worksheet.Columns.AutoFit();

                // highlight cells with mass value zero
                //foreach (Range cell in worksheet.UsedRange.Cells)
                //{
                //    if (cell.Value != null && cell.Value.ToString() == "0")
                //    {
                //        cell.Interior.Color = ColorTranslator.ToOle(Color.Red);
                //    }
                //}
            }


            // Move Zero Mass sheet to beginning
            zeroMassSheet.Move(workbook.Sheets[1]);

            // Move summary sheet to beginning
            summarySheet.Move(workbook.Sheets[2]);

            // Save and close the workbook
            workbook.SaveAs(@"C:\Users\HP\Downloads\DICV\AssemblyData.xlsx");
            workbook.Close();
            excel.Quit();
        }

        public static ComponentData FillMassAndCgOfComponent(Component iComp, ComponentData iParent,int level)
        {
            UFWeight.UnitsType use_units;
            if (workPart.PartUnits == BasePart.Units.Millimeters)
            {
                use_units = UFWeight.UnitsType.UnitsKmm;
            }
            else
            {
                use_units = UFWeight.UnitsType.UnitsLi;
            }
            UFWeight.Properties props = new UFWeight.Properties();
            UFWeight.Exceptions[] exceptions = { new UFWeight.Exceptions() };
            theUfSession.Weight.EstabCompProps1(iComp.Tag, 0.99, true, use_units, out props, out exceptions);
            double propsMass = Math.Round(props.mass, 2);

            ComponentData componentData = new ComponentData();
            componentData.Component = iComp;
            componentData.Level = level;
            componentData.CompName = iComp.DisplayName;
            componentData.CgX = Math.Round(props.center_of_mass[0],2);
            componentData.CgY = Math.Round(props.center_of_mass[1], 2);
            componentData.CgZ = Math.Round(props.center_of_mass[2], 2);
            componentData.Mass = propsMass;
            componentData.Parent = iParent;

            //Echo("");
            //Echo("Level : " + level);
            //Echo("Part Name : " + iComp.DisplayName);
            //Echo("Center of Mass : " + propsMass + " Kg");
            //Echo("Xcbar = " + props.center_of_mass[0]);
            //Echo("Ycbar = " + props.center_of_mass[1]);
            //Echo("Zcbar = " + props.center_of_mass[2]);

            Echo(String.Format("{0,-8}{1,-40}{2,-20}{3,-20}{4,-20}{5,-20}",
                level,
                iComp.DisplayName,
                propsMass + " Kg",
                Math.Round(props.center_of_mass[0], 2),
                Math.Round(props.center_of_mass[1], 2),
                Math.Round(props.center_of_mass[2], 2)));




            return componentData;
        }
        public static void ReportComponentsWithZeroMass(Component parent,ref List<ComponentData> compsWithZeroMass)
        {
            Component[] children = parent.GetChildren();

            foreach (Component child in children)
            {
                if (child.IsSuppressed || child.IsBlanked)
                {
                    continue;
                }
                try
                {
                    UFWeight.UnitsType use_units;
                    if (workPart.PartUnits == BasePart.Units.Millimeters)
                    {
                        use_units = UFWeight.UnitsType.UnitsKmm;
                    }
                    else
                    {
                        use_units = UFWeight.UnitsType.UnitsLi;
                    }

                    UFWeight.Properties props = new UFWeight.Properties();
                    UFWeight.Exceptions[] exceptions = { new UFWeight.Exceptions() };

                    theUfSession.Weight.EstabCompProps1(child.Tag, 0.99, true, use_units, out props, out exceptions);
                    double propsMass = Math.Round(props.mass, 2);
                    if (propsMass <= 0)
                    {
                        ComponentData componentData = new ComponentData();
                        componentData.CompName = child.DisplayName;
                        componentData.Mass = propsMass;
                        compsWithZeroMass.Add(componentData);
                    }
                    ReportComponentsWithZeroMass(child,ref compsWithZeroMass);
                }
                catch
                {
                }
            }
        }
        private static void Echo(string message)
        {
            Session.GetSession().ListingWindow.WriteLine(message);
        }
        public static int GetUnloadOption(string dummy) { return (int)NXOpen.Session.LibraryUnloadOption.Immediately; }
    }
}