﻿using System.Collections.Generic;
using NXOpen;
using NXOpen.Assemblies;
using NXOpen.BlockStyler;
using NXOpen.Features;

namespace FemAutomation
{
    public class PartData
    {
        public string PartId { get; set; }
        public string PartNumber { get; set; }
        public Component CadComponent { get; set; }
        public Constants.PartType? PartType { get; set; }
        public Constants.MeshType? MeshType { get; set; }
        public Constants.MeshElementType? MeshElementType { get; set; }
        public Constants.YesOrNo? IsSurfaceContact { get; set; }
        public Node TreeNode { get; set; }
        public string Thickness { get; set; }
        public BodyFeature LinkedBodyFeature { get; set; }
        public List<Feature>MidSurfaceFeatures { get; set; }
        public List<Feature> DivideSurfaceFeatures { get; set; }
        public bool IsMidSurfaceCreated { get; set; }
        public string Material { get; set; }
        public PartData()
        {
            PartNumber = string.Empty;
            CadComponent = null;
            PartType = Constants.PartType.SheetMetal;
            MeshType = Constants.MeshType.Mesh2D;
            MeshElementType = Constants.MeshElementType.CTETRA4;
            IsSurfaceContact = Constants.YesOrNo.No;
            TreeNode = null;
            Thickness = "0.0";
            PartId = "0";
            LinkedBodyFeature = null;
            IsMidSurfaceCreated = false;
            MidSurfaceFeatures = new List<Feature>(0);
            DivideSurfaceFeatures = new List<Feature>(0);
            Material = string.Empty;
        }
    }
}