﻿namespace KerbWeightCalculation
{
    public class ChildPartData
    {
        public double NxMass { get; set; }
        public double NxCgX { get; set; }
        public double NxCgY { get; set; }
        public double NxCgZ { get; set; }
    }
}