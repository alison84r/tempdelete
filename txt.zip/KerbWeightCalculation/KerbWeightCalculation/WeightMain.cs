﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Microsoft.Office.Interop.Excel;
using NXOpen;
using NXOpen.Assemblies;
using NXOpen.Features.AECDesign;
using NXOpen.Markup;
using NXOpen.UF;
using static NXOpen.LoadOptions;
using Excel = Microsoft.Office.Interop.Excel;

namespace KerbWeightCalculation
{
    public class WeightMain
    {
        private static Session theSession = Session.GetSession();
        private static UI theUI = UI.GetUI();
        private static UFSession theUfSession = UFSession.GetUFSession();
        private static int numParts = 0;
        private static Part workPart = theSession.Parts.Work;
        private static KerbWeightInputForm kerbweightUi = null;
        public static void Main(string[] args)
        {

            kerbweightUi = new KerbWeightInputForm();
            NXOpenUI.FormUtilities.SetApplicationIcon(kerbweightUi);
            NXOpenUI.FormUtilities.ReparentForm(kerbweightUi);

            DialogResult dialogResult = kerbweightUi.ShowDialog();
            if (dialogResult == DialogResult.OK)
            {
                // Start timer
                DateTime startTime = DateTime.Now;

                // ListingWindow lw = theSession.ListingWindow;
                Part workPart = theSession.Parts.Work;

                //lw.Open();
                //lw.WriteLine(workPart.FullPath);
                numParts += 1;
                int level = 0;

                List<Component> zeroMassComponents = new List<Component>();
                Component rootComp = workPart.ComponentAssembly.RootComponent;
                if (rootComp != null)
                {
                    List<ComponentData> rootComponentDatas = new List<ComponentData>(0);
                    List<Component> firstLevelChildComponents = GetFirstLevelChildComponents(rootComp, "MOD");
                    int fstLevelCnt = 1;
                    foreach (Component level1Component in firstLevelChildComponents)
                    {
                        theUfSession.Ui.SetStatus("Processing Component " + level1Component.DisplayName + "...");
                        ComponentData firstLevelChildComponentData = new ComponentData();
                        firstLevelChildComponentData.Component = level1Component;
                        firstLevelChildComponentData.Level = 1;
                        firstLevelChildComponentData.CompName = level1Component.DisplayName.ToUpper();
                        firstLevelChildComponentData.CgX = 0;
                        firstLevelChildComponentData.CgY = 0;
                        firstLevelChildComponentData.CgZ = 0;
                        firstLevelChildComponentData.Mass = 0;
                        firstLevelChildComponentData.Parent = null;
                        firstLevelChildComponentData.Child = new List<ComponentData>(0);



                        NXOpen.UF.UFWeight.Properties level1ComponentProps = new NXOpen.UF.UFWeight.Properties();
                        double level1ComponentMass = 0.0;

                        InitializeProperties(ref level1ComponentProps); // Initialize with default values

                        CalculateCenterOfMass(level1Component, ref level1ComponentProps, ref level1ComponentMass);

                        CalculateWeightedAverage(ref level1ComponentProps, level1ComponentMass);

                        firstLevelChildComponentData.CgX = level1ComponentProps.center_of_mass[0];
                        firstLevelChildComponentData.CgY = level1ComponentProps.center_of_mass[1];
                        firstLevelChildComponentData.CgZ = level1ComponentProps.center_of_mass[2];
                        firstLevelChildComponentData.Mass = level1ComponentMass;


                        rootComponentDatas.Add(firstLevelChildComponentData);


                        List<string> subStringZnumbers = new List<string>()
                            { "Z0", "Z1", "Z2", "Z3", "Z4", "Z5", "Z6", "Z7", "Z8", "Z9" };
                        List<Component> childComponentsByZnumbers =
                            GetChildComponentsBySubstring(level1Component, subStringZnumbers);

                        foreach (Component zComponent in childComponentsByZnumbers)
                        {
                            theUfSession.Ui.SetStatus("Processing Component " + zComponent.DisplayName + "...");
                            ComponentData ZComponentData = new ComponentData();
                            ZComponentData.Component = zComponent;
                            ZComponentData.Level = 3;
                            ZComponentData.CompName = zComponent.DisplayName.ToUpper();
                            ZComponentData.CgX = 0;
                            ZComponentData.CgY = 0;
                            ZComponentData.CgZ = 0;
                            ZComponentData.Mass = 0;
                            ZComponentData.Parent = firstLevelChildComponentData;

                            NXOpen.UF.UFWeight.Properties zComponentProps = new NXOpen.UF.UFWeight.Properties();
                            double zComponentMass = 0.0;

                            InitializeProperties(ref zComponentProps); // Initialize with default values

                            CalculateCenterOfMass(zComponent, ref zComponentProps, ref zComponentMass);

                            CalculateWeightedAverage(ref zComponentProps, zComponentMass);

                            ZComponentData.CgX = zComponentProps.center_of_mass[0];
                            ZComponentData.CgY = zComponentProps.center_of_mass[1];
                            ZComponentData.CgZ = zComponentProps.center_of_mass[2];
                            ZComponentData.Mass = zComponentMass;

                            firstLevelChildComponentData.Child.Add(ZComponentData);
                        }

                    }

                    // Remove duplicates based on DisplayName
                    zeroMassComponents = zeroMassComponents.Distinct(new ComponentDisplayNameComparer()).ToList();
                    WriteToExcel(rootComponentDatas, zeroMassComponents);
                }

                // End timer
                DateTime endTime = DateTime.Now;

                // Calculate elapsed time in minutes
                TimeSpan timeElapsed = endTime - startTime;
                double minutesElapsed = Math.Round(timeElapsed.TotalMinutes, 2);

                // Print elapsed time
                theUI.NXMessageBox.Show("Kerb Weight", NXMessageBox.DialogType.Information,
                    "KERB Weight Calculation completed in " + minutesElapsed + " minutes");
                Console.WriteLine("Elapsed time: " + minutesElapsed + " minutes");
            }
        }

        public static List<Component> GetFirstLevelChildComponents(Component rootComponent, string nameContains)
        {
            List<Component> firstLevelChildComponents = new List<Component>();

            foreach (Component child in rootComponent.GetChildren())
            {
                if (child.IsSuppressed || child.IsBlanked)
                {
                    continue;
                }
                string partType = GetPartTypeAttribute(child);
                if (partType.Equals("ASM") && child.Name.Contains(nameContains))
                    firstLevelChildComponents.Add(child);
            }

            return firstLevelChildComponents;
        }

        private static string GetPartTypeAttribute(Component component)
        {
            string partType = string.Empty;
            string attributeValue = GetStringAttributeValue(component, "RNI_PARTTYPE");
            if (!string.IsNullOrEmpty(attributeValue))
            {
                partType = attributeValue;
            }
            return partType;
        }

        public static List<Component> GetChildComponentsBySubstring(Component rootComponent, List<string> subStringZnumbers)
        {
            
            List<Component> childComponents = new List<Component>();
            TraverseComponent(rootComponent, childComponents, subStringZnumbers);
            return childComponents;
        }

        private static void TraverseComponent(Component component, List<Component> matchingComponents, List<string> subStringZnumbers)
        {
            string partType = GetPartTypeAttribute(component);
            // Check if the component name contains any of the subStringZnumbers
            foreach (string nameSubstring in subStringZnumbers)
            {
                if (component.Name.ToUpper().Contains(nameSubstring.ToUpper()))
                {
                    matchingComponents.Add(component);
                    // Break out of the inner loop as we already found a match
                    break;
                }
            }

            if (partType.Equals("ASM"))
            {
                foreach (Component child in component.GetChildren())
                {
                    if (child.IsSuppressed || child.IsBlanked)
                    {
                        continue;
                    }
                    TraverseComponent(child, matchingComponents, subStringZnumbers);
                }
            }
        }
        
        public static double GetDoubleAttributeValue(NXObject iNxObject, string iAttributeName)
        {
            string attributeValue = GetStringAttributeValue(iNxObject, iAttributeName);

            double result;
            if (string.IsNullOrEmpty(attributeValue) || !double.TryParse(attributeValue, out result))
            {
                result = 0.0;
            }

            return result;
        }
        public static string GetStringAttributeValue(NXObject iNxObject, string iAttributeName)
        {
            string attributeValue = "";
            if(!string.IsNullOrEmpty(iAttributeName))
            {
                if (iNxObject.HasUserAttribute(iAttributeName, NXObject.AttributeType.String, -1))
                {
                    attributeValue = iNxObject.GetStringUserAttribute(iAttributeName, -1);
                }
            }
            return attributeValue;
        }
        
        public static void WriteToExcel(List<ComponentData> level1CompsData, List<Component> zeroMassComponents)
        {
            // Create a new Excel workbook
            Excel.Application excel = new Excel.Application();
            Excel.Workbook workbook = excel.Workbooks.Add();

            int row = 2;

            //Add the Sheet for zero Mass Components
            Worksheet zeroMassSheet = (Worksheet)workbook.Sheets.Add();
            zeroMassSheet.Name = "Zero Mass";
            zeroMassSheet.Cells[1, 1].Value = "Name";
            zeroMassSheet.Cells[1, 2].Value = "Mass in Kgs";
            foreach (Component compWithZeroMass in zeroMassComponents)
            {
                zeroMassSheet.Cells[row, 1].Value = compWithZeroMass.DisplayName.ToUpper();
                zeroMassSheet.Cells[row, 2].Value = 0;

                row++;
            }

            row = 2;

            // Add the summary sheet
            Worksheet summarySheet = (Worksheet)workbook.Sheets.Add();
            summarySheet.Name = "Summary";
            summarySheet.Cells[1, 1].Value = "Name";
            summarySheet.Cells[1, 2].Value = "Mass in Kgs";

            summarySheet.Cells[1, 3].Value = "CgX";
            summarySheet.Cells[1, 4].Value = "CgY";
            summarySheet.Cells[1, 5].Value = "CgZ";

            summarySheet.Cells[1, 6].Value = "Mx";
            summarySheet.Cells[1, 7].Value = "My";
            summarySheet.Cells[1, 8].Value = "Mz";



            double totalMass = 0;
            double totalMx = 0; //Total CGx of Vehicle
            double totalMy = 0; //Total CGy of Vehicle
            double totalMz = 0; //Total CGz of Vehicle





            // Loop through the top-level components and add them to the summary sheet
            foreach (ComponentData componentData in level1CompsData)
            {

                summarySheet.Cells[row, 1].Value = componentData.CompName;
                summarySheet.Cells[row, 2].Value = Math.Round(componentData.Mass, 2);
                summarySheet.Cells[row, 3].Value = Math.Round(componentData.CgX, 2);
                summarySheet.Cells[row, 4].Value = Math.Round(componentData.CgY, 2);
                summarySheet.Cells[row, 5].Value = Math.Round(componentData.CgZ, 2);
                summarySheet.Cells[row, 6].Value = Math.Round(componentData.CgX * componentData.Mass, 2);
                summarySheet.Cells[row, 7].Value = Math.Round(componentData.CgY * componentData.Mass, 2);
                summarySheet.Cells[row, 8].Value = Math.Round(componentData.CgZ * componentData.Mass, 2);

                row++;

               // totalMass = totalMass + Math.Round(componentData.Mass, 2);
               // totalMx = totalMx + Math.Round(componentData.CgX * componentData.Mass, 2);
               // totalMy = totalMy + Math.Round(componentData.CgY * componentData.Mass, 2);
               // totalMz = totalMz + Math.Round(componentData.CgZ * componentData.Mass, 2);
                

                // Add a new sheet for the component
                Worksheet componentSheet = (Worksheet)workbook.Sheets.Add();
                componentSheet.Name = componentData.CompName;
                componentSheet.Cells[1, 1].Value = "Name";
                componentSheet.Cells[1, 2].Value = "Mass in Kgs";
                componentSheet.Cells[1, 3].Value = "CgX";
                componentSheet.Cells[1, 4].Value = "CgY";
                componentSheet.Cells[1, 5].Value = "CgZ";
                componentSheet.Cells[1, 6].Value = "Mx";
                componentSheet.Cells[1, 7].Value = "My";
                componentSheet.Cells[1, 8].Value = "Mz";

                // Loop through the child components and add them to the component sheet
                int childRow = 2;
                foreach (ComponentData childComponentData in componentData.Child)
                {
                    componentSheet.Cells[childRow, 1].Value = childComponentData.CompName;
                    componentSheet.Cells[childRow, 2].Value = childComponentData.Mass;
                    componentSheet.Cells[childRow, 3].Value = childComponentData.CgX;
                    componentSheet.Cells[childRow, 4].Value = childComponentData.CgY;
                    componentSheet.Cells[childRow, 5].Value = childComponentData.CgZ;
                    componentSheet.Cells[childRow, 6].Value = childComponentData.CgX * childComponentData.Mass;
                    componentSheet.Cells[childRow, 7].Value = childComponentData.CgY * childComponentData.Mass;
                    componentSheet.Cells[childRow, 8].Value = childComponentData.CgZ * childComponentData.Mass;
                    

                    if (childComponentData.Mass == 0)
                    {
                        componentSheet.Cells[childRow, 2].Interior.Color = Excel.XlRgbColor.rgbRed;
                    }

                    childRow++;
                }
            }


            //Add Some Columns at the end of the sheet
            double endRowCnt = row;
            double summarySheetRowCnt = row + 3;
            summarySheet.Cells[summarySheetRowCnt, 2].Value = "Wheelbase (mm):";
            summarySheet.Cells[summarySheetRowCnt, 3].Value = kerbweightUi.wheelBase; //D49
            summarySheetRowCnt++;

            summarySheet.Cells[summarySheetRowCnt, 2].Value = "Front Axle Spacing (mm):";
            summarySheet.Cells[summarySheetRowCnt, 3].Value = kerbweightUi.frontAxleSpacing; //D50
            summarySheetRowCnt++;

            summarySheet.Cells[summarySheetRowCnt, 2].Value = "Rear Axle Spacing (mm):";
            summarySheet.Cells[summarySheetRowCnt, 3].Value = kerbweightUi.rearAxleSpacing; //D51
            summarySheetRowCnt++;

            summarySheet.Cells[summarySheetRowCnt, 2].Value = "CGx of vehicle (mm):";
            string totalMassX = "=SUM(F2:F" + (endRowCnt) + ")";
            summarySheet.Cells[summarySheetRowCnt, 3].Formula = totalMassX; //D52
            totalMx = summarySheet.Cells[summarySheetRowCnt, 3].Value;
            summarySheetRowCnt++;

            summarySheet.Cells[summarySheetRowCnt, 2].Value = "CGy of vehicle (mm):";
            string totalMassY = "=SUM(G2:G" + (endRowCnt) + ")";
            summarySheet.Cells[summarySheetRowCnt, 3].Formula = totalMassY; //D53
            totalMy = summarySheet.Cells[summarySheetRowCnt, 3].Value;
            summarySheetRowCnt++;

            summarySheet.Cells[summarySheetRowCnt, 2].Value = "CGz of vehicle (mm):";
            string totalMassZ = "=SUM(H2:H" + (endRowCnt) + ")";
            summarySheet.Cells[summarySheetRowCnt, 3].Formula = totalMassZ; //D54
            totalMz = summarySheet.Cells[summarySheetRowCnt, 3].Value;
            summarySheetRowCnt++;

            summarySheetRowCnt++;
            summarySheetRowCnt++;

            summarySheet.Cells[summarySheetRowCnt, 2].Value = "Kerb weight (kg):";
            //= SUM(B2: B19)
            string totalMassSum = "=SUM(B2:B" + (endRowCnt) + ")";
            summarySheet.Cells[summarySheetRowCnt, 3].Formula = totalMassSum; //57
            totalMass = summarySheet.Cells[summarySheetRowCnt, 3].Value;

            summarySheetRowCnt++;

            summarySheet.Cells[summarySheetRowCnt, 2].Value = "Raw (kg):";
            //=((D52-(D50/2))/(D49-(D50/2)+(D51/2)))*D57
            double kerbweightUiFrontAxleSpacing = (totalMx - kerbweightUi.frontAxleSpacing / 2) /
                                                     (kerbweightUi.wheelBase -
                                                      kerbweightUi.frontAxleSpacing / 2 +
                                                      kerbweightUi.rearAxleSpacing / 2);
            double raw = kerbweightUiFrontAxleSpacing* totalMass;
            summarySheet.Cells[summarySheetRowCnt, 3].Value =raw;
            summarySheetRowCnt++;

            summarySheet.Cells[summarySheetRowCnt, 2].Value = "Faw (kg):";
            summarySheet.Cells[summarySheetRowCnt, 3].Value = totalMass - raw;
            summarySheetRowCnt++;



            // loop through all sheets
            foreach (Worksheet ws in workbook.Worksheets)
            {
                // set current sheet as active sheet
                Worksheet worksheet = ws;
                worksheet.Activate();

                // set first row as header and make it bold
                Range headerRange = worksheet.Range["A1", "E1"];
                headerRange.Font.Bold = true;

                // set fill color for header
                headerRange.Interior.Color = ColorTranslator.ToOle(Color.LightGray);

                // auto-adjust columns
                worksheet.Columns.AutoFit();

                // highlight cells with mass value zero
                //foreach (Range cell in worksheet.UsedRange.Cells)
                //{
                //    if (cell.Value != null && cell.Value.ToString() == "0")
                //    {
                //        cell.Interior.Color = ColorTranslator.ToOle(Color.Red);
                //    }
                //}
            }


            // Move Zero Mass sheet to beginning
            zeroMassSheet.Move(workbook.Sheets[1]);

            // Move summary sheet to beginning
            summarySheet.Move(workbook.Sheets[2]);

            // Save and close the workbook
            workbook.SaveAs(@"C:\Users\HP\Downloads\DICV\AssemblyData.xlsx");
            workbook.Close();
            excel.Quit();
        }

        static void InitializeProperties(ref NXOpen.UF.UFWeight.Properties properties)
        {
            properties.center_of_mass = new double[3];
            properties.center_of_mass[0] = 0.0;
            properties.center_of_mass[1] = 0.0;
            properties.center_of_mass[2] = 0.0;
        }
        static void CalculateWeightedAverage(ref NXOpen.UF.UFWeight.Properties totalProps, double totalMass)
        {
            if (totalMass != 0)
            {
                totalProps.center_of_mass[0] = Math.Round(totalProps.center_of_mass[0] / totalMass, 3);
                totalProps.center_of_mass[1] = Math.Round(totalProps.center_of_mass[1] / totalMass, 3);
                totalProps.center_of_mass[2] = Math.Round(totalProps.center_of_mass[2] / totalMass, 3);
            }
        }

        static void CalculateCenterOfMass(Component component, ref NXOpen.UF.UFWeight.Properties totalProps, ref double totalMass)
        {
            if (component != null)
            {
                List<Component> childComponents = new List<Component>();
                GetAllChildComponents(component, ref childComponents);
                if (childComponents.Count > 0)
                {
                    foreach (var childComponent in childComponents)
                    {
                        NXOpen.UF.UFWeight.Properties componentProps = new NXOpen.UF.UFWeight.Properties();
                        NXOpen.UF.UFWeight.Exceptions exceptions = new NXOpen.UF.UFWeight.Exceptions();

                        try
                        {
                            theUfSession.Weight.EstabCompProps(childComponent.Tag, 0.99, false,
                                UFWeight.UnitsType.UnitsKmm, out componentProps, out exceptions);
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e);

                        }

                        if (componentProps.center_of_mass != null)
                        {
                            //Calculate the weight;
                            double componentMass = GetDoubleAttributeValue(childComponent, "j0WeightCalc");
                            //double componentMass = componentProps.mass; // Assuming mass is the first element

                            totalMass += componentMass;

                            totalProps.center_of_mass[0] += componentProps.center_of_mass[0] * componentMass;
                            totalProps.center_of_mass[1] += componentProps.center_of_mass[1] * componentMass;
                            totalProps.center_of_mass[2] += componentProps.center_of_mass[2] * componentMass;
                        }
                    }
                }
                else
                {
                    NXOpen.UF.UFWeight.Properties componentProps = new NXOpen.UF.UFWeight.Properties();
                    NXOpen.UF.UFWeight.Exceptions exceptions = new NXOpen.UF.UFWeight.Exceptions();

                    try
                    {
                        theUfSession.Weight.EstabCompProps(component.Tag, 0.99, false,
                            UFWeight.UnitsType.UnitsKmm, out componentProps, out exceptions);
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);

                    }

                    if (componentProps.center_of_mass != null)
                    {
                        //Calculate the weight;
                        double componentMass = GetDoubleAttributeValue(component, "j0WeightCalc");
                        //double componentMass = componentProps.mass; // Assuming mass is the first element

                        totalMass += componentMass;

                        totalProps.center_of_mass[0] += componentProps.center_of_mass[0] * componentMass;
                        totalProps.center_of_mass[1] += componentProps.center_of_mass[1] * componentMass;
                        totalProps.center_of_mass[2] += componentProps.center_of_mass[2] * componentMass;
                    }
                }


            }
        }
        static void GetAllChildComponents(Component parentComponent, ref List<Component> childComponents)
        {
            Component[] children = parentComponent.GetChildren();

            foreach (Component child in children)
            {

                string stringAttributeValue = GetStringAttributeValue(child, "RNI_PARTTYPE");
                if (!string.IsNullOrEmpty(stringAttributeValue) && stringAttributeValue.Equals("PRT"))
                {
                    childComponents.Add(child);
                }

                GetAllChildComponents(child, ref childComponents);
            }
        }
        
        public static int GetUnloadOption(string dummy) { return (int)NXOpen.Session.LibraryUnloadOption.Explicitly; }
    }
}