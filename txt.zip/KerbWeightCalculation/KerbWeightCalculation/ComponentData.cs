﻿using System.Collections.Generic;
using NXOpen.Assemblies;

namespace KerbWeightCalculation
{
    public class ComponentData
    {
        public string CompName { get; set; }
        public Component Component { get; set; }
        public double Mass { get; set; }
        public double CgX { get; set; }
        public double CgY { get; set; }
        public double CgZ { get; set; }
        public int Level { get; set; }

        public ComponentData Parent { get; set; }
        public List<ComponentData> Child { get; set; }

    }
}