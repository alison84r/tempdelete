﻿namespace KerbWeightCalculation
{
    partial class KerbWeightInputForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.wheelbaselbl = new System.Windows.Forms.Label();
            this.frontAxleSpacinglbl = new System.Windows.Forms.Label();
            this.rearAxleSpacinglbl = new System.Windows.Forms.Label();
            this.wheelBaseTxtBx = new System.Windows.Forms.TextBox();
            this.frontAxleSpacingTxtbx = new System.Windows.Forms.TextBox();
            this.RearAxleSpacingTxtbx = new System.Windows.Forms.TextBox();
            this.okBtn = new System.Windows.Forms.Button();
            this.cancelBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // wheelbaselbl
            // 
            this.wheelbaselbl.AutoSize = true;
            this.wheelbaselbl.Location = new System.Drawing.Point(12, 21);
            this.wheelbaselbl.Name = "wheelbaselbl";
            this.wheelbaselbl.Size = new System.Drawing.Size(90, 13);
            this.wheelbaselbl.TabIndex = 0;
            this.wheelbaselbl.Text = "Wheel Base (mm)";
            // 
            // frontAxleSpacinglbl
            // 
            this.frontAxleSpacinglbl.AutoSize = true;
            this.frontAxleSpacinglbl.Location = new System.Drawing.Point(12, 48);
            this.frontAxleSpacinglbl.Name = "frontAxleSpacinglbl";
            this.frontAxleSpacinglbl.Size = new System.Drawing.Size(121, 13);
            this.frontAxleSpacinglbl.TabIndex = 1;
            this.frontAxleSpacinglbl.Text = "Front Axle Spacing (mm)";
            // 
            // rearAxleSpacinglbl
            // 
            this.rearAxleSpacinglbl.AutoSize = true;
            this.rearAxleSpacinglbl.Location = new System.Drawing.Point(12, 78);
            this.rearAxleSpacinglbl.Name = "rearAxleSpacinglbl";
            this.rearAxleSpacinglbl.Size = new System.Drawing.Size(120, 13);
            this.rearAxleSpacinglbl.TabIndex = 2;
            this.rearAxleSpacinglbl.Text = "Rear Axle Spacing (mm)";
            // 
            // wheelBaseTxtBx
            // 
            this.wheelBaseTxtBx.Location = new System.Drawing.Point(144, 17);
            this.wheelBaseTxtBx.Name = "wheelBaseTxtBx";
            this.wheelBaseTxtBx.Size = new System.Drawing.Size(100, 20);
            this.wheelBaseTxtBx.TabIndex = 3;
            // 
            // frontAxleSpacingTxtbx
            // 
            this.frontAxleSpacingTxtbx.Location = new System.Drawing.Point(144, 44);
            this.frontAxleSpacingTxtbx.Name = "frontAxleSpacingTxtbx";
            this.frontAxleSpacingTxtbx.Size = new System.Drawing.Size(100, 20);
            this.frontAxleSpacingTxtbx.TabIndex = 4;
            // 
            // RearAxleSpacingTxtbx
            // 
            this.RearAxleSpacingTxtbx.Location = new System.Drawing.Point(144, 74);
            this.RearAxleSpacingTxtbx.Name = "RearAxleSpacingTxtbx";
            this.RearAxleSpacingTxtbx.Size = new System.Drawing.Size(100, 20);
            this.RearAxleSpacingTxtbx.TabIndex = 5;
            // 
            // okBtn
            // 
            this.okBtn.Location = new System.Drawing.Point(152, 109);
            this.okBtn.Name = "okBtn";
            this.okBtn.Size = new System.Drawing.Size(31, 23);
            this.okBtn.TabIndex = 6;
            this.okBtn.Text = "Ok";
            this.okBtn.UseVisualStyleBackColor = true;
            this.okBtn.Click += new System.EventHandler(this.okBtn_Click);
            // 
            // cancelBtn
            // 
            this.cancelBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cancelBtn.Location = new System.Drawing.Point(194, 109);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(53, 23);
            this.cancelBtn.TabIndex = 7;
            this.cancelBtn.Text = "Cancel";
            this.cancelBtn.UseVisualStyleBackColor = true;
            // 
            // KerbWeightInputForm
            // 
            this.AcceptButton = this.okBtn;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.CancelButton = this.cancelBtn;
            this.ClientSize = new System.Drawing.Size(257, 143);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.okBtn);
            this.Controls.Add(this.RearAxleSpacingTxtbx);
            this.Controls.Add(this.frontAxleSpacingTxtbx);
            this.Controls.Add(this.wheelBaseTxtBx);
            this.Controls.Add(this.rearAxleSpacinglbl);
            this.Controls.Add(this.frontAxleSpacinglbl);
            this.Controls.Add(this.wheelbaselbl);
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(273, 182);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(273, 182);
            this.Name = "KerbWeightInputForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.Label wheelbaselbl;
        private System.Windows.Forms.Label frontAxleSpacinglbl;
        public System.Windows.Forms.Label rearAxleSpacinglbl;
        private System.Windows.Forms.TextBox wheelBaseTxtBx;
        private System.Windows.Forms.TextBox frontAxleSpacingTxtbx;
        private System.Windows.Forms.TextBox RearAxleSpacingTxtbx;
        private System.Windows.Forms.Button okBtn;
        private System.Windows.Forms.Button cancelBtn;
    }
}