﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KerbWeightCalculation
{
    public partial class KerbWeightInputForm : Form
    {
        public double wheelBase;
        public double frontAxleSpacing;
        public double rearAxleSpacing;

        public KerbWeightInputForm()
        {
            InitializeComponent();

            // Assign OK and Cancel buttons to the main form
            this.AcceptButton = okBtn;
            this.CancelButton = cancelBtn;

            // Set default values for text boxes
            wheelBaseTxtBx.Text = "6300";
            frontAxleSpacingTxtbx.Text = "1730";
            RearAxleSpacingTxtbx.Text = "1500";

            // Attach event handlers for validating numeric input
            wheelBaseTxtBx.TextChanged += NumericTextBox_TextChanged;
            frontAxleSpacingTxtbx.TextChanged += NumericTextBox_TextChanged;
            RearAxleSpacingTxtbx.TextChanged += NumericTextBox_TextChanged;
        }

        private void NumericTextBox_TextChanged(object sender, EventArgs e)
        {
            TextBox textBox = (TextBox)sender;

            // Remove non-numeric characters and extra decimal points
            string text = textBox.Text;
            text = new string(text.Where(c => char.IsDigit(c) || c == '.' || c == ',').ToArray());
            text = text.Replace(",", ".");

            // Limit to 4 decimal places
            if (text.Count(c => c == '.') > 1)
            {
                int lastIndex = text.LastIndexOf('.');
                text = text.Substring(0, lastIndex) + text.Substring(lastIndex).Replace(".", "");
            }
            else if (text.Contains("."))
            {
                int decimalIndex = text.IndexOf('.');
                if (text.Length - decimalIndex > 5)
                {
                    text = text.Substring(0, decimalIndex + 5);
                }
            }

            textBox.Text = text;
            textBox.SelectionStart = text.Length;
        }

        private void okBtn_Click(object sender, EventArgs e)
        {
            
            if (double.TryParse(wheelBaseTxtBx.Text, out wheelBase))
            {
                if (wheelBase == 0)
                {
                    MessageBox.Show("Please enter a non-zero value for Wheel Base.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid numeric value for Wheel Base.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            
            if (double.TryParse(frontAxleSpacingTxtbx.Text, out frontAxleSpacing))
            {
                if (frontAxleSpacing == 0)
                {
                    MessageBox.Show("Please enter a non-zero value for Front Axle Spacing.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid numeric value for Front Axle Spacing.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

           
            if (double.TryParse(RearAxleSpacingTxtbx.Text, out rearAxleSpacing))
            {
                if (rearAxleSpacing == 0)
                {
                    MessageBox.Show("Please enter a non-zero value for Rear Axle Spacing.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid numeric value for Rear Axle Spacing.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Proceed further with the numeric values...
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void KerbWeightInputForm_Load(object sender, EventArgs e)
        {

        }
    }
}
