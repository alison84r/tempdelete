﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NXOpen;

namespace FemAutomation
{
    public class FemAutomationMain
    {
        public static SessionData SessionData;
        public static void Main(string[] args)
        {
            SessionData = new SessionData();
            NxHelper nxHelper = new NxHelper(SessionData);
            nxHelper.CreateFemSimulationSolution();
            SessionData.TheUi.NXMessageBox.Show("I am activated", NXMessageBox.DialogType.Information, "I am ");

        }

        public static int GetUnloadOption(string dummy)
        {
            return (int)Session.LibraryUnloadOption.Immediately;
        }
    }
}
