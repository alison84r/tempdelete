﻿using System;
using System.IO;
using NXOpen;
using NXOpen.CAE;
using NXOpen.CAE.Xyplot;

namespace FemAutomation
{
    public class NxHelper
    {
        private SessionData _sessionData;
        public NxHelper(SessionData sessionData)
        {
            _sessionData = sessionData;
        }

        public void CreateFemSimulationSolution()
        {
            _sessionData.TheSession.ApplicationSwitchImmediate("UG_APP_SFEM");
            var baseTemplateManager1 = _sessionData.TheSession.XYPlotManager.TemplateManager;

            try
            {
                Part partsDisplay = _sessionData.TheSession.Parts.Display;
                if (partsDisplay != null)
                {
                    string partsDisplayName = partsDisplay.Name;
                    string partsDisplayFullPath = partsDisplay.FullPath;
                    FileInfo fileInfo = new FileInfo(partsDisplayFullPath);
                    string directoryFullPath = fileInfo.DirectoryName; // contains "C:\MyDirectory"


                    string partName = Path.GetFileNameWithoutExtension(partsDisplayFullPath);
                    string femPartName = partName + "_fem.fem";
                    if (directoryFullPath != null)
                    {
                        string femPartFullPath = Path.Combine(directoryFullPath, femPartName);
                        BasePart basePart1 =
                            _sessionData.TheSession.Parts.NewBaseDisplay(femPartFullPath,
                                BasePart.Units.Millimeters);

                        //workPart = null;
                        //displayPart = null;
                        FemPart workFemPart = ((FemPart)_sessionData.TheSession.Parts.BaseWork);
                        FemPart displayFemPart = ((FemPart)_sessionData.TheSession.Parts.BaseDisplay);
                        FemPart femPart1 = workFemPart;
                        femPart1.PolygonGeometryMgr.SetPolygonBodyResolutionOnFemBodies(PolygonGeometryManager
                            .PolygonBodyResolutionType.Standard);

                        FemPart femPart2 = workFemPart;
                        FemCreationOptions femCreationOptions1 = femPart2.NewFemCreationOptions();

                        FemPart femPart3 = workFemPart;
                        FemSynchronizeOptions femSynchronizeOptions1 = femPart3.NewFemSynchronizeOptions();

                        Part part1 = partsDisplay;
                        string femIPartName = partName + "_fem1_i.fem";
                        string femIPartFullPath = Path.Combine(directoryFullPath, femIPartName);
                        femCreationOptions1.SetCadData(part1, femIPartFullPath);

                        //NXOpen.Body[] bodies1 = new NXOpen.Body[2];
                        //NXOpen.Assemblies.Component component1 = ((NXOpen.Assemblies.Component)part1.ComponentAssembly.RootComponent.FindObject("COMPONENT trigger 1"));
                        //NXOpen.Body body1 = ((NXOpen.Body)component1.FindObject("PARTIAL_PROTO#.Bodies|Body7"));
                        //bodies1[0] = body1;
                        //NXOpen.Assemblies.Component component2 = ((NXOpen.Assemblies.Component)part1.ComponentAssembly.RootComponent.FindObject("COMPONENT base 1"));
                        //NXOpen.Body body2 = ((NXOpen.Body)component2.FindObject("PARTIAL_PROTO#.Bodies|Body7"));
                        //bodies1[1] = body2;
                        //femCreationOptions1.SetGeometryOptions(NXOpen.CAE.FemCreationOptions.UseBodiesOption.VisibleBodies, bodies1, femSynchronizeOptions1);

                        femCreationOptions1.SetLayerVisibilityOptions(FemCreationOptions.LayerVisibilityOption
                            .Part);

                        femCreationOptions1.SetSolverOptions("NX NASTRAN", "Structural",
                            BaseFemPart.AxisymAbstractionType.None);

                        string[] description1 = new string[0];
                        femCreationOptions1.SetDescription(description1);

                        femCreationOptions1.SetMorphingFlag(false);

                        femCreationOptions1.SetCyclicSymmetryData(false, null);

                        FemPart femPart4 = workFemPart;
                        femPart4.FinalizeCreation(femCreationOptions1);

                        femSynchronizeOptions1.Dispose();
                        femCreationOptions1.Dispose();
                        BaseTemplateManager baseTemplateManager2 =
                            _sessionData.TheSession.XYPlotManager.TemplateManager;

                        string simPartName = partName + "_sim1.sim";
                        string simPartFullPath = Path.Combine(directoryFullPath, simPartName);
                        BasePart basePart2 =
                            _sessionData.TheSession.Parts.NewBaseDisplay(simPartFullPath, BasePart.Units.Millimeters);

                        SimPart workSimPart = ((SimPart)_sessionData.TheSession.Parts.BaseWork);
                        SimPart displaySimPart = ((SimPart)_sessionData.TheSession.Parts.BaseDisplay);
                        SimPart simPart1 = workSimPart;
                        string[] description2 = new string[0];
                        simPart1.FinalizeCreation(femPart4, -1, description2);

                        workSimPart.ModelingViews.WorkView.Regenerate();
                        _sessionData.TheSession.CleanUpFacetedFacesAndEdges();

                        //Solution
                        SimPart simPart2 = workSimPart;
                        SimSimulation simSimulation1 = simPart2.Simulation;

                        SimSolution simSolution1 = simSimulation1.CreateSolution("NX NASTRAN", "Structural",
                            "SESTATIC 101 - Single Constraint", "Solution 1",
                            SimSimulation.AxisymAbstractionType.None);

                        PropertyTable propertyTable1 = simSolution1.PropertyTable;

                        CaePart caePart1 = workSimPart;
                        ModelingObjectPropertyTable modelingObjectPropertyTable1 =
                            caePart1.ModelingObjectPropertyTables.CreateModelingObjectPropertyTable(
                                "Bulk Data Echo Request", "NX NASTRAN - Structural", "NX NASTRAN",
                                "Bulk Data Echo Request1", 1);

                        CaePart caePart2 = workSimPart;
                        ModelingObjectPropertyTable modelingObjectPropertyTable2 =
                            caePart2.ModelingObjectPropertyTables.CreateModelingObjectPropertyTable(
                                "Structural Output Requests", "NX NASTRAN - Structural", "NX NASTRAN",
                                "Structural Output Requests1", 2);

                        NXOpen.Session.UndoMarkId markId10;
                        markId10 = _sessionData.TheSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, null);

                        PropertyTable propertyTable2 = simSolution1.PropertyTable;

                        propertyTable2.SetNamedPropertyTablePropertyValue("Bulk Data Echo Request",
                            modelingObjectPropertyTable1);

                        propertyTable2.SetNamedPropertyTablePropertyValue("Output Requests",
                            modelingObjectPropertyTable2);

                        Session.UndoMarkId id1 = _sessionData.TheSession.NewestVisibleUndoMark;

                        int nErrs1;
                        nErrs1 = _sessionData.TheSession.UpdateManager.DoUpdate(id1);

                        SimSolutionStep simSolutionStep1 = simSolution1.CreateStep(0, true, "Subcase - Static Loads 1");

                        int nErrs2;
                        nErrs2 = _sessionData.TheSession.UpdateManager.DoUpdate(markId10);

                        _sessionData.TheSession.DeleteUndoMark(markId10, null);

                        _sessionData.TheSession.SetUndoMarkName(id1, "Solution");

                        _sessionData.TheSession.CleanUpFacetedFacesAndEdges();

                        _sessionData.TheSession.Parts.SetWork(femPart4);

                        workFemPart =
                            ((NXOpen.CAE.FemPart)_sessionData.TheSession.Parts.BaseWork); // wave_component_fem1
                        _sessionData.TheSession.CleanUpFacetedFacesAndEdges();
                    }

                }

                _sessionData.TheUi.NXMessageBox.Show("SIM creation", NXMessageBox.DialogType.Information,
                    "FEM and SIM solution created");
            }
            catch (Exception e)
            {
                _sessionData.TheUi.NXMessageBox.Show("SIM creation", NXMessageBox.DialogType.Error,
                    "FEM and SIM solution creation Failed");
            }
        }
    }
}